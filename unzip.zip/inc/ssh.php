<?php


$sshaddress = "IP-ADRESS";
$sshport = "SSH_PORT";
$sshroot = "root";
$sshpassword = "SSH_PASSWORD";



?>